#include "triangle.h"

#include <GL/glew.h>

#include "object_manager.h"
#include "line.h"
#include "vertexarray.h"


Triangle::Triangle(const glm::vec2& left, const glm::vec2& right,
	const glm::vec2& mid, ObjectManager* manager, const glm::vec2& pathStart, const glm::vec2& pathEnd)
	: Object{ manager },
	mLeftPoint{ left },
	mRightPoint{ right },
	mMidPoint{ mid },
	mPath{ nullptr },
	mVertexArray{ nullptr }
{
	SetType(Type::kTriangle);

	mPoints.emplace_back(mLeftPoint);
	mPoints.emplace_back(mRightPoint);
	mPoints.emplace_back(mMidPoint);

	mSides.emplace_back(Side{ left, mid });
	mSides.emplace_back(Side{ right, mid });
	mSides.emplace_back(Side{ left, right });
	Load();

	if (pathStart != glm::vec2{ 0.0f, 0.0f })
	{
		mPath = new Line{ pathStart, pathEnd };
		manager->AddPath(mPath);
	}
}

Triangle::~Triangle()
{
	delete mVertexArray;

	if (mPath)
	{
		mManager->RemovePath(mPath);
		delete mPath;
	}
}

void Triangle::Update()
{
	if (GetState() == State::kActive)
	{
		Object::Update();

		auto speed = GetXSpeed();
		mLeftPoint.x += speed;
		mRightPoint.x += speed;
		mMidPoint.x += speed;

		speed = GetYSpeed();
		mLeftPoint.y += speed;
		mRightPoint.y += speed;
		mMidPoint.y += speed;

		UpdateSide();
		Load();

		if (mLeftPoint.x < -1.3f || mRightPoint.x > 1.3f
			|| mLeftPoint.y < -1.3f)
			SetState(State::kDead);
	}
}

void Triangle::Draw()
{
	mVertexArray->SetActive();
	glDrawElements(GL_TRIANGLES, mVertexArray->GetNumIndices(),
		GL_UNSIGNED_INT, nullptr);
}

void Triangle::Load()
{
	const float vertices[] = {
		mLeftPoint.x, mLeftPoint.y,
		mRightPoint.x, mRightPoint.y,
		mMidPoint.x, mMidPoint.y
	};

	const unsigned int indices[] = {
		0, 1, 2,
	};

	if (mVertexArray)
		delete mVertexArray;
	mVertexArray = new VertexArray(vertices, static_cast < unsigned int>(sizeof(vertices) / sizeof(float)),
		indices, static_cast<unsigned int>(sizeof(indices) / sizeof(unsigned int)));
}

void Triangle::UpdateSide()
{
	mPoints.clear();
	mPoints.emplace_back(mLeftPoint);
	mPoints.emplace_back(mRightPoint);
	mPoints.emplace_back(mMidPoint);

	mSides.clear();
	mSides.emplace_back(Side{ mLeftPoint, mMidPoint });
	mSides.emplace_back(Side{ mRightPoint, mMidPoint });
	mSides.emplace_back(Side{ mLeftPoint, mRightPoint });
}

const glm::vec2 Triangle::GetCenter() const
{
	return glm::vec2{
		(mLeftPoint.x + mRightPoint.x + mMidPoint.x) / 3,
		(mLeftPoint.y + mRightPoint.y + mMidPoint.y) / 3
	};
}

void Triangle::Rearrange(const glm::vec2& center)
{
	glm::vec2 prevCenter = GetCenter();
	glm::vec2 leftCen = mLeftPoint - prevCenter;
	glm::vec2 rightCen = mRightPoint - prevCenter;
	glm::vec2 midCen = mMidPoint - prevCenter;

	mLeftPoint = center + leftCen;
	mRightPoint = center + rightCen;
	mMidPoint = center + midCen;

	Load();
}